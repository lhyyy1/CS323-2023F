### Environment

Ubuntu 22.04

gcc 11.4.0

### How to run

```
gcc lex.c -o lex
./lex<test1.spl
./lex<test2.spl
```
